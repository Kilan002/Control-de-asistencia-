data class AlumnoAsistencia(
    val nombre: String = "",
    val matricula: String = "",
    val grupo: String = "",
    val fechaHora: String = "",
    var conteo: Int = 0
)