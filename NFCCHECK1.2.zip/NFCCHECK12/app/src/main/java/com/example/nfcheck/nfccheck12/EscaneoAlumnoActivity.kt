package com.example.nfcheck.nfccheck12

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class EscaneoAlumnoActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_escaneo_alumno)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC no disponible", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        val filters = arrayOf(IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED))
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, filters, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        if (intent.action == NfcAdapter.ACTION_TAG_DISCOVERED) {
            val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
            val idBytes = tag?.id
            val tagId = idBytes?.joinToString("") { String.format("%02X", it) }

            if (tagId != null) {
                verificarAlumno(tagId)
            }
        }
    }

    private fun verificarAlumno(tagId: String) {
        val ref = FirebaseDatabase.getInstance().getReference("alumnos").child(tagId)
        ref.get().addOnSuccessListener { snapshot ->
            if (snapshot.exists()) {
                val matricula = snapshot.child("matricula").value.toString()
                val nombre = snapshot.child("nombre").value.toString()

                // Pasar a MateriaActivity
                val intent = Intent(this, MateriaActivity::class.java)
                intent.putExtra("matricula", matricula)
                intent.putExtra("nombre", nombre)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Alumno no registrado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}