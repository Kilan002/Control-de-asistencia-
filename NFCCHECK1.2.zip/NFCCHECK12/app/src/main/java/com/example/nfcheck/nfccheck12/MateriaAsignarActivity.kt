package com.example.nfcheck.nfccheck12

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class MateriaAsignarActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_materia_asignar)

        val spinnerGrupo = findViewById<Spinner>(R.id.spinnerGrupo)
        val spinnerMateria = findViewById<Spinner>(R.id.spinnerMateria)
        val btnGuardar = findViewById<Button>(R.id.botonGuardarMateria)

        val grupos = arrayOf("RBM11", "RBM21", "RBM31")
        val materias = arrayOf(
            "INTEGRADORA",
            "CIRCUITOS DIG.",
            "CIRCUITOS AN.",
            "PROYECTO INT.",
            "CALCULO INT.",
            "DESARROLLO",
            "INGLES"
        )

        spinnerGrupo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, grupos)
        spinnerMateria.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, materias)

        btnGuardar.setOnClickListener {
            val grupo = spinnerGrupo.selectedItem.toString()
            val materia = spinnerMateria.selectedItem.toString()

            val ref = FirebaseDatabase.getInstance().getReference("materias_por_grupo")
            ref.child(grupo).setValue(materia)
                .addOnSuccessListener {
                    Toast.makeText(this, "Materia '$materia' asignada a $grupo", Toast.LENGTH_SHORT).show()
                }
        }
    }
}