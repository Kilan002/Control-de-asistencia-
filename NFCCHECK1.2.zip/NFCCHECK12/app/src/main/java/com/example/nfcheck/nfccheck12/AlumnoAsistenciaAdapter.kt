package com.example.nfcheck.nfccheck12

import AlumnoAsistencia
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class AlumnoAsistenciaAdapter(private val listaAlumnos: MutableList<AlumnoAsistencia>) :
    RecyclerView.Adapter<AlumnoAsistenciaAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nombre: TextView = view.findViewById(R.id.itemNombre)
        val matricula: TextView = view.findViewById(R.id.itemMatricula)
        val fechaHora: TextView = view.findViewById(R.id.itemFechaHora)
        val asistencias: TextView = view.findViewById(R.id.itemAsistencias)
        val btnVerFechas: Button = view.findViewById(R.id.btnVerFechas)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_fila_asistencia, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val alumno = listaAlumnos[position]
        holder.nombre.text = "Nombre: ${alumno.nombre}"
        holder.matricula.text = "Matrícula: ${alumno.matricula}"
        holder.fechaHora.text = "" // Ocultamos la fecha como pediste
        holder.asistencias.text = "Asistencias: ${alumno.conteo}"

        holder.btnVerFechas.setOnClickListener {
            val context = holder.itemView.context
            val grupo = alumno.grupo
            val matricula = alumno.matricula

            if (grupo.isNotEmpty() && matricula.isNotEmpty()) {
                val intent = Intent(context, DetalleAsistenciasActivity::class.java)
                intent.putExtra("grupo", grupo)
                intent.putExtra("matricula", matricula)
                intent.putExtra("nombre", alumno.nombre)
                context.startActivity(intent)
            } else {
                Toast.makeText(context, "Datos Incompletos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun getItemCount(): Int = listaAlumnos.size
}