package com.example.nfcheck.nfccheck12

import AlumnoAsistencia
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class ListaGruActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlumnoAsistenciaAdapter
    private lateinit var textViewTituloGrupo: TextView
    private val listaAlumnos = mutableListOf<AlumnoAsistencia>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_gru)

        recyclerView = findViewById(R.id.recyclerViewAlumnos)
        textViewTituloGrupo = findViewById(R.id.textViewTituloGrupo)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AlumnoAsistenciaAdapter(listaAlumnos)
        recyclerView.adapter = adapter

        val grupo = intent.getStringExtra("grupo")
        textViewTituloGrupo.text = "Grupo: $grupo"

        if (grupo != null) {
            cargarAsistencias(grupo)
        } else {
            Toast.makeText(this, "No se recibió grupo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cargarAsistencias(grupo: String) {
        val dbRef = FirebaseDatabase.getInstance().getReference("asistencias").child(grupo)

        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val conteoMap = mutableMapOf<String, AlumnoAsistencia>()
                for (matriculaSnapshot in snapshot.children) {
                    val matricula = matriculaSnapshot.key ?: continue
                    var nombre = ""
                    var contador = 0

                    for (asistenciaSnap in matriculaSnapshot.children) {
                        val tipo = asistenciaSnap.child("tipo").getValue(String::class.java)
                        if (tipo == "asistencia") {
                            nombre =
                                asistenciaSnap.child("nombre").getValue(String::class.java) ?: ""
                            contador++
                        }
                    }

                    if (contador > 0 && nombre.isNotEmpty()) {
                        val alumno = AlumnoAsistencia(
                            nombre = nombre,
                            matricula = matricula,
                            grupo = grupo, // 👈 MUY IMPORTANTE
                            fechaHora = "", // se deja en blanco para esta vista
                            conteo = contador
                        )
                        val key = "$nombre|$matricula"
                        conteoMap[key] = alumno
                    }
                }

                listaAlumnos.clear()
                listaAlumnos.addAll(conteoMap.values)
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ListaGruActivity, "Error al cargar datos", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }
}