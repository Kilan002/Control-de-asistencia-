package com.example.nfcheck.nfccheck12

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class GruposActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_grupos)

        val btnRBM11 = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.RBM11)
        val btnRBM21 = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.RBM21)
        val btnRBM31 = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.RBM31)

        btnRBM11.setOnClickListener { navigateToGrupo("RBM11") }
        btnRBM21.setOnClickListener { navigateToGrupo("RBM21") }
        btnRBM31.setOnClickListener { navigateToGrupo("RBM31") }
    }

    private fun navigateToGrupo(nombreGrupo: String) {
        val intent = Intent(this, ListaGruActivity::class.java)
        intent.putExtra("grupo", nombreGrupo)
        startActivity(intent)
    }
    }
