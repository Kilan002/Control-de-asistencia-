package com.example.nfcheck.nfccheck12

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MateriaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_materia)

        val botonesMaterias = mapOf(
            R.id.M1 to "INTEGRADORA",
            R.id.M2 to "CIRCUITOS DIG.",
            R.id.M3 to "CIRCUITOS AN.",
            R.id.M4 to "PROYECTO INT.",
            R.id.M5 to "CALCULO INT.",
            R.id.M6 to "DESARROLLO",
            R.id.M7 to "INGLES"
        )

        for ((idBoton, materia) in botonesMaterias) {
            findViewById<Button>(idBoton).setOnClickListener {
                val intent = Intent(this, AsistenciasMateriaActivity::class.java)
                intent.putExtra("materia", materia)
                startActivity(intent)
            }
        }
    }
}