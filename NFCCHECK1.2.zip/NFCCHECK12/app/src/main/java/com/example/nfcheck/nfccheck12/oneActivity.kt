package com.example.nfcheck.nfccheck12

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class oneActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_one)
        val btnProfe = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.PROFE)
        val btnEST = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.EST)

        btnProfe.setOnClickListener { navigateToopc() }
        btnEST.setOnClickListener { navigateToREG() }

        }

    private fun navigateToopc() {
        val intent = Intent(this, ContraActivity::class.java)
        startActivity(intent)
    }
    private fun navigateToREG(){
        val intent = Intent(this, MateriaActivity::class.java)
        startActivity(intent)
    }
}
