package com.example.nfcheck.nfccheck12

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

@Suppress("DEPRECATION")
class REGActivity : AppCompatActivity() {


    private var nfcAdapter: NfcAdapter? = null
    private lateinit var textViewNombre: TextView
    private lateinit var textViewMatricula: TextView
    private lateinit var textViewGrupo: TextView
    private lateinit var textViewFechaHora: TextView
    private lateinit var textViewMateria: TextView

    private fun navigateToMatMan(){
        val intent = Intent(this, AsistenciaManualActivity::class.java)
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_regactivity)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC no disponible", Toast.LENGTH_SHORT).show()
            finish()
        }

        textViewNombre = findViewById(R.id.textViewNombre)
        textViewMatricula = findViewById(R.id.textViewMatricula)
        textViewGrupo = findViewById(R.id.textViewgrupoAlumno)
        textViewFechaHora = findViewById(R.id.textViewFechaHora)
        textViewMateria = findViewById(R.id.textViewMateria) // NUEVO TextView para mostrar la materia

        val fechaHoraActual = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        textViewFechaHora.text = "Fecha y hora: $fechaHoraActual"
        val btnMatMan = findViewById<Button>(R.id.buttonAsistenciaManual)
        btnMatMan.setOnClickListener { navigateToMatMan() }
    }

    override fun onResume() {
        super.onResume()
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        val filters = arrayOf(IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED))
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, filters, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        if (intent.action == NfcAdapter.ACTION_TAG_DISCOVERED) {
            val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
            val idBytes = tag?.id
            val tagId = idBytes?.joinToString("") { String.format("%02X", it) }

            if (tagId != null) {
                registrarAsistencia(tagId)
            }
        }
    }

    private fun registrarAsistencia(tagId: String) {
        val db = FirebaseDatabase.getInstance().reference
        db.child("alumnos").child(tagId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val nombre = snapshot.child("nombre").value.toString()
                    val matricula = snapshot.child("matricula").value.toString()
                    val grupo = snapshot.child("grupo").value.toString()

                    // 🔹 Obtener materia automáticamente según el grupo
                    db.child("materias_por_grupo").child(grupo)
                        .addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(materiaSnap: DataSnapshot) {
                                val materia = materiaSnap.getValue(String::class.java) ?: "Sin materia asignada"

                                val fechaHora = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
                                val asistencia = mapOf(
                                    "nombre" to nombre,
                                    "matricula" to matricula,
                                    "grupo" to grupo,
                                    "materia" to materia,
                                    "fechaHora" to fechaHora,
                                    "tipo" to "asistencia"
                                )

                                db.child("asistencias").child(grupo).child(matricula).push().setValue(asistencia)

                                Toast.makeText(this@REGActivity, "Asistencia registrada", Toast.LENGTH_SHORT).show()

                                // Mostrar datos en pantalla
                                textViewNombre.text = nombre
                                textViewMatricula.text = matricula
                                textViewGrupo.text = grupo
                                textViewMateria.text = "Materia: $materia"
                                textViewFechaHora.text = "Fecha y hora: $fechaHora"
                            }

                            override fun onCancelled(error: DatabaseError) {
                                Toast.makeText(this@REGActivity, "Error al obtener materia", Toast.LENGTH_SHORT).show()
                            }
                        })
                } else {
                    Toast.makeText(this@REGActivity, "NFC no registrado", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@REGActivity, "Error de base de datos", Toast.LENGTH_SHORT).show()
            }
        })
    }
}