package com.example.nfcheck.nfccheck12

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

@Suppress("DEPRECATION")
class PruebaActivity : AppCompatActivity() {

//Identificar NFC
    private var nfcAdapter: NfcAdapter? = null
    private var tagIdActual: String? = null

//Inicio de la Activity
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prueba)

    //Seleccionar Grupo
        val spinnerGrupo = findViewById<Spinner>(R.id.spinnerGrupo)
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.grupos_array,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGrupo.adapter = adapter

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC no disponible", Toast.LENGTH_SHORT).show()
            finish()
        }

        val btnGuardar = findViewById<Button>(R.id.buttonGuardar)
        val editNombre = findViewById<EditText>(R.id.editTextNombre)
        val editMatricula = findViewById<EditText>(R.id.editTextMatricula)

        btnGuardar.setOnClickListener {
            val nombre = editNombre.text.toString().trim()
            val matricula = editMatricula.text.toString().trim()
            findViewById<Spinner>(R.id.spinnerGrupo)

            if (tagIdActual == null) {
                Toast.makeText(this, "Escanea un llavero NFC primero", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nombre.isEmpty() || matricula.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val grupo = spinnerGrupo.selectedItem.toString()
            val alumno = mapOf("nombre" to nombre, "matricula" to matricula, "grupo" to grupo)
            val db = FirebaseDatabase.getInstance().reference
            db.child("alumnos").child(tagIdActual!!).setValue(alumno).addOnSuccessListener {
                Toast.makeText(this, "Alumno registrado con éxito", Toast.LENGTH_SHORT).show()
                editNombre.text.clear()
                editMatricula.text.clear()
                tagIdActual = null
            }.addOnFailureListener {
                Toast.makeText(this, "Error al guardar en Firebase", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //Activar escaneo de NFC
    override fun onResume() {
        super.onResume()
        val intent = Intent(this, javaClass).apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        val filters = arrayOf(IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED))
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, filters, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)


        //Identificar ID
        if (intent.action == NfcAdapter.ACTION_TAG_DISCOVERED) {
            val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
            val idBytes = tag?.id
            tagIdActual = idBytes?.joinToString("") { String.format("%02X", it) }

            if (tagIdActual != null) {
                Toast.makeText(this, "Llavero NFC escaneado: $tagIdActual", Toast.LENGTH_SHORT).show()
                findViewById<TextView>(R.id.textViewTagId).text = "ID NFC: $tagIdActual"
            } else {
                Toast.makeText(this, "No se pudo leer el NFC", Toast.LENGTH_SHORT).show()
            }
        }
    }
}