package com.example.nfcheck.nfccheck12

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class DetalleAsistenciasActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AsistenciaAdapter
    private val listaFechas = mutableListOf<String>()

    private lateinit var nombreText: TextView
    private lateinit var matriculaText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_asistencias)

        recyclerView = findViewById(R.id.recyclerViewAsistencias)
        recyclerView.layoutManager = LinearLayoutManager(this)
         adapter = AsistenciaAdapter(listaFechas)
        recyclerView.adapter = adapter

        nombreText = findViewById(R.id.textNombre)
        matriculaText = findViewById(R.id.textMatricula)

        val grupo = intent.getStringExtra("grupo")
        val matricula = intent.getStringExtra("matricula")
        val nombre = intent.getStringExtra("nombre")

        if (grupo != null && matricula != null && nombre != null) {
            nombreText.text = "Nombre: $nombre"
            matriculaText.text = "Matrícula: $matricula"
            cargarAsistencias(grupo, matricula)
        } else {
            Toast.makeText(this, "Datos incompletos", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun cargarAsistencias(grupo: String, matricula: String) {
        val ref = FirebaseDatabase.getInstance().getReference("asistencias").child(grupo).child(matricula)

        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                listaFechas.clear()
                for (asistenciaSnap in snapshot.children) {
                    val fechaHora = asistenciaSnap.child("fechaHora").getValue(String::class.java)
                    if (!fechaHora.isNullOrEmpty()) {
                        listaFechas.add(fechaHora)
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@DetalleAsistenciasActivity, "Error al cargar asistencias", Toast.LENGTH_SHORT).show()
            }
        })
    }
}