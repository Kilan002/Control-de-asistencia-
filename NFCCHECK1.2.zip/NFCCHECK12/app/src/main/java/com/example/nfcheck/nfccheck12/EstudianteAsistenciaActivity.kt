package com.example.nfcheck.nfccheck12

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class EstudianteAsistenciaActivity : AppCompatActivity() {

    private lateinit var nfcAdapter: NfcAdapter
    private lateinit var nombreText: TextView
    private lateinit var matriculaText: TextView
    private lateinit var grupoText: TextView
    private lateinit var asistenciasText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_estudiante_asistencia)

        nombreText = findViewById(R.id.nombreText)
        matriculaText = findViewById(R.id.matriculaText)
        grupoText = findViewById(R.id.grupoText)
        asistenciasText = findViewById(R.id.asistenciasText)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            Toast.makeText(this, "Este dispositivo no soporta NFC", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        tag?.let {
            val tagId = it.id.joinToString("") { byte -> "%02X".format(byte) }
            buscarAlumnoPorTag(tagId)
        }
    }

    private fun buscarAlumnoPorTag(tagId: String) {
        val alumnoRef = FirebaseDatabase.getInstance().getReference("alumnos").child(tagId)

        alumnoRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val nombre = snapshot.child("nombre").value.toString()
                    val matricula = snapshot.child("matricula").value.toString()
                    val grupo = snapshot.child("grupo").value.toString()

                    nombreText.text = "Nombre: $nombre"
                    matriculaText.text = "Matrícula: $matricula"
                    grupoText.text = "Grupo: $grupo"

                    // Contar solo asistencias reales
                    val ref = FirebaseDatabase.getInstance()
                        .getReference("asistencias").child(grupo).child(matricula)

                    ref.addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            var contador = 0
                            for (child in snapshot.children) {
                                val tipo = child.child("tipo").value?.toString()
                                if (tipo == "asistencia") {
                                    contador++
                                }
                            }
                            asistenciasText.text = "Asistencias: $contador"
                        }

                        override fun onCancelled(error: DatabaseError) {
                            asistenciasText.text = "Error al contar asistencias"
                        }
                    })

                } else {
                    Toast.makeText(
                        this@EstudianteAsistenciaActivity,
                        "NFC no registrado",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(
                    this@EstudianteAsistenciaActivity,
                    "Error de base de datos",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}