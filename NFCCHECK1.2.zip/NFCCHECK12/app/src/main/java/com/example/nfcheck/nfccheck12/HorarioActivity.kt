package com.example.nfcheck.nfccheck12

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class HorarioActivity : AppCompatActivity() {

    private lateinit var imageViewHorario: ImageView    //	Muestra la imagen del horario en pantalla.
    private val PICK_IMAGE_REQUEST = 1                  // Código para identificar el resultado de la galería.
    private val PREFS_KEY = "HorarioPrefs"              // Nombre del archivo donde se guardan datos
    private val IMAGE_URI_KEY = "imageUri"              // URL de la imagen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_horario)

        val btnSeleccionar = findViewById<Button>(R.id.btnSeleccionarHorario)
        imageViewHorario = findViewById(R.id.imageViewHorario)

        // Cargar imagen guardada (si existe)
        val prefs = getSharedPreferences(PREFS_KEY, MODE_PRIVATE)
        val savedUri = prefs.getString(IMAGE_URI_KEY, null)
        savedUri?.let {
            Glide.with(this).load(Uri.parse(it)).into(imageViewHorario)
        }

        btnSeleccionar.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            val imageUri = data.data
            imageUri?.let {
                Glide.with(this).load(it).into(imageViewHorario)

                // Guardar URI
                val prefs = getSharedPreferences(PREFS_KEY, MODE_PRIVATE)
                prefs.edit().putString(IMAGE_URI_KEY, it.toString()).apply()
            }
        }
    }
}