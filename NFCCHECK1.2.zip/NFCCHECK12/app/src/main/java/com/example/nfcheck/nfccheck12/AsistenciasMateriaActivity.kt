package com.example.nfcheck.nfccheck12

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class AsistenciasMateriaActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null
    private lateinit var spinnerMaterias: Spinner
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AsistenciaAdapter
    private val listaAsistencias = mutableListOf<String>()

    private var alumnoGrupo: String? = null
    private var alumnoMatricula: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asistencias_materia)

        spinnerMaterias = findViewById(R.id.spinnerMaterias)
        recyclerView = findViewById(R.id.recyclerAsistencias)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AsistenciaAdapter(listaAsistencias)
        recyclerView.adapter = adapter

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC no disponible", Toast.LENGTH_SHORT).show()
            finish()
        }

        // Acción al seleccionar materia
        spinnerMaterias.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val materiaSeleccionada = spinnerMaterias.selectedItem?.toString()
                if (materiaSeleccionada != null && alumnoGrupo != null && alumnoMatricula != null) {
                    cargarAsistencias(alumnoGrupo!!, alumnoMatricula!!, materiaSeleccionada)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    override fun onResume() {
        super.onResume()
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        val filters = arrayOf(IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED))
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, filters, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == NfcAdapter.ACTION_TAG_DISCOVERED) {
            val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
            val idBytes = tag?.id
            val tagId = idBytes?.joinToString("") { String.format("%02X", it) }

            if (tagId != null) {
                obtenerDatosAlumno(tagId)
            }
        }
    }

    private fun obtenerDatosAlumno(tagId: String) {
        val db = FirebaseDatabase.getInstance().reference
        db.child("alumnos").child(tagId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    alumnoGrupo = snapshot.child("grupo").value.toString()
                    alumnoMatricula = snapshot.child("matricula").value.toString()

                    // Cargar materias asignadas a este grupo
                    db.child("materias_por_grupo").child(alumnoGrupo!!)
                        .addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(materiaSnap: DataSnapshot) {
                                val materia = materiaSnap.getValue(String::class.java)
                                if (materia != null) {
                                    spinnerMaterias.adapter = ArrayAdapter(this@AsistenciasMateriaActivity,
                                        android.R.layout.simple_spinner_dropdown_item, listOf(materia))
                                }
                            }
                            override fun onCancelled(error: DatabaseError) {}
                        })
                } else {
                    Toast.makeText(this@AsistenciasMateriaActivity, "NFC no registrado", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun cargarAsistencias(grupo: String, matricula: String, materia: String) {
        val db = FirebaseDatabase.getInstance().reference
        db.child("asistencias").child(grupo).child(matricula)
            .orderByChild("materia").equalTo(materia)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listaAsistencias.clear()
                    for (asistenciaSnap in snapshot.children) {
                        val fechaHora = asistenciaSnap.child("fechaHora").value.toString()
                        listaAsistencias.add(fechaHora)
                    }
                    adapter.notifyDataSetChanged()
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }
}
