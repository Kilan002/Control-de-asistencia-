package com.example.nfcheck.nfccheck12

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText

class ContraActivity : AppCompatActivity() {
    private val PASSWORD = "1234567" // Contraseña

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contra)

        val btnContinuar = findViewById<AppCompatButton>(R.id.Cont)
        val inputContrasena = findViewById<AppCompatEditText>(R.id.Contraseña)
        val mensajeError = findViewById<TextView>(R.id.ConMal)

        btnContinuar.setOnClickListener {
            val contrasenaIngresada = inputContrasena.text?.toString()?.trim()

            if (contrasenaIngresada == PASSWORD) {
                mensajeError.text = "" // Limpia mensaje
                startActivity(Intent(this, opcActivity::class.java))
            } else {
                mensajeError.text = "Contraseña incorrecta"
            }
        }
    }
}