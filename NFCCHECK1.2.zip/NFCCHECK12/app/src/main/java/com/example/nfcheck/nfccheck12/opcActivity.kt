package com.example.nfcheck.nfccheck12

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class opcActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_opc)
        val btnREG = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.REG)
        val btnAsi = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.ASI)
        val btnGru = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.GRU)
        val btnHor = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.HOR)
        val btnMat = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.MAT)
        btnREG.setOnClickListener { navigateToREG() }
        btnAsi.setOnClickListener { navigateToPru() }
        btnGru.setOnClickListener { navigateToGru() }
        btnHor.setOnClickListener { navigateToHor() }
        btnMat.setOnClickListener { navigateToMat() }
    }

    private fun navigateToREG(){
        val intent = Intent(this, PruebaActivity::class.java)
        startActivity(intent)
    }
    private fun navigateToPru(){
        val intent = Intent(this, REGActivity::class.java)
        startActivity(intent)
    }
    private fun navigateToGru(){
        val intent = Intent(this, GruposActivity::class.java)
        startActivity(intent)
    }
    private fun navigateToHor(){
        val intent = Intent(this, HorarioActivity::class.java)
        startActivity(intent)
    }
    private fun navigateToMat(){
        val intent = Intent(this, MateriaAsignarActivity::class.java)
        startActivity(intent)
    }
}