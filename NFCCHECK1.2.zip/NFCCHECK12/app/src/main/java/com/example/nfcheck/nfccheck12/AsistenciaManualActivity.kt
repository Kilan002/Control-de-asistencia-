package com.example.nfcheck.nfccheck12

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.*

class AsistenciaManualActivity : AppCompatActivity() {

    private lateinit var spinnerGrupo: Spinner
    private lateinit var spinnerMateria: Spinner
    private lateinit var autoCompleteMatricula: AutoCompleteTextView
    private lateinit var botonRegistrar: Button
    private lateinit var textResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asistencia_manual)

        spinnerGrupo = findViewById(R.id.spinnerGrupo)
        spinnerMateria = findViewById(R.id.spinnerMateria)
        autoCompleteMatricula = findViewById(R.id.autoCompleteMatricula)
        botonRegistrar = findViewById(R.id.buttonRegistrarManual)
        textResultado = findViewById(R.id.textResultado)

        // Lista de grupos
        val grupos = arrayOf("RBM11", "RBM21", "RBM31")
        spinnerGrupo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, grupos)

        // Lista de materias
        val materias = arrayOf(
            "INTEGRADORA",
            "CIRCUITOS DIGITALES",
            "CIRCUITOS ANALÓGICOS",
            "PROYECTO INTEGRADOR",
            "CÁLCULO INTEGRAL",
            "DESARROLLO",
            "INGLÉS"
        )
        spinnerMateria.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, materias)

        // Cargar matrículas desde Firebase
        val alumnosRef = FirebaseDatabase.getInstance().reference.child("alumnos")
        alumnosRef.get().addOnSuccessListener { snapshot ->
            val listaMatriculas = mutableListOf<String>()
            for (alumnoSnap in snapshot.children) {
                val matricula = alumnoSnap.child("matricula").value.toString()
                if (matricula.isNotEmpty()) listaMatriculas.add(matricula)
            }
            val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, listaMatriculas)
            autoCompleteMatricula.setAdapter(adapter)
        }

        // Registrar asistencia
        botonRegistrar.setOnClickListener {
            val matriculaIngresada = autoCompleteMatricula.text.toString().trim()
            val grupoSeleccionado = spinnerGrupo.selectedItem.toString()
            val materiaSeleccionada = spinnerMateria.selectedItem.toString()

            if (matriculaIngresada.isEmpty()) {
                Toast.makeText(this, "Escribe una matrícula", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            alumnosRef.get().addOnSuccessListener { snapshot ->
                var encontrado = false
                for (alumnoSnap in snapshot.children) {
                    val matricula = alumnoSnap.child("matricula").value.toString()
                    if (matricula == matriculaIngresada) {
                        encontrado = true
                        val nombre = alumnoSnap.child("nombre").value.toString()
                        val grupo = alumnoSnap.child("grupo").value.toString()

                        val fechaHora = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
                        val asistencia = mapOf(
                            "nombre" to nombre,
                            "matricula" to matricula,
                            "grupo" to grupo,
                            "materia" to materiaSeleccionada,
                            "fechaHora" to fechaHora,
                            "tipo" to "asistencia"
                        )

                        FirebaseDatabase.getInstance().reference
                            .child("asistencias")
                            .child(grupo)   // 🔹 Usamos el grupo real del alumno
                            .child(matricula)
                            .push()
                            .setValue(asistencia)
                            .addOnSuccessListener {
                                textResultado.text = "✅ Asistencia registrada para: $nombre ($matricula) en $materiaSeleccionada"
                            }
                        break
                    }
                }
                if (!encontrado) {
                    Toast.makeText(this, "Matrícula no encontrada", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}